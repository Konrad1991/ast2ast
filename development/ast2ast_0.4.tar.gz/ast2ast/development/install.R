setwd("/home/konrad/Documents")
install.packages("ast2ast", type = "source", repos = NULL)
