#!/bin/bash

Rscript install.R

Rscript errorManagement.R

# Rscript test.R

# Rscript testsAll.R
