#!/bin/bash

Rscript install.R

Rscript test.R

# Rscript testsAll.R
