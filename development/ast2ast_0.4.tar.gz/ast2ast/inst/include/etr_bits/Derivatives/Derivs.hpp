#ifndef DERIVS_ETR_H
#define DERIVS_ETR_H

#include "../BinaryCalculations.hpp"
#include "../Core.hpp"
#include "../UnaryCalculations.hpp"
#include "AllVars.hpp"
#include "DerivTypes.hpp"
#include "VarPointer.hpp"
#include "getDerivs.hpp"

#endif
