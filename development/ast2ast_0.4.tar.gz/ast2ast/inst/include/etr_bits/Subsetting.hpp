#ifndef SUBSETTING
#define SUBSETTING

#include "Subsetting/MatrixSubsetting.hpp"
#include "Subsetting/ScalarSubsetting.hpp"
#include "Subsetting/VectorSubsetting.hpp"
#include "Subsetting/at.hpp"

#endif
