if (requireNamespace("tinytest", quietly = FALSE)) {
  tinytest::test_package("ast2ast")
}
