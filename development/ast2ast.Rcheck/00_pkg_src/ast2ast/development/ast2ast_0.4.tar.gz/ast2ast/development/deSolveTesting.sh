#!/bin/bash

cd ~/Documents/dsa2a/

Rscript install.R
Rscript run.R
