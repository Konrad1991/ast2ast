source("../R/FunctionMapping.R")
l <- list(2, 2)
f <- "matrix"
order_args(l, f)
matrix(2, 2)
