#ifndef ALLOCATION_ETR_H
#define ALLOCATION_ETR_H

#include "Allocation/AllocationUtils.hpp"
#include "Allocation/Colon.hpp"
#include "Allocation/Matrix.hpp"
#include "Allocation/Rep.hpp"
#include "Allocation/ScalarForDeriv.hpp"
#include "Allocation/Vector.hpp"

#endif
